"""Compiled implementation modules for stVirtual."""

__version__ = "0.1.0.dev0"
