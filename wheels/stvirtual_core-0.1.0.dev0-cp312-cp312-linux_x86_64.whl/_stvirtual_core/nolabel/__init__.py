"""Compiled no-label model implementations."""
